export const HEADER = {
    Authorization: 'Authorization',
};
